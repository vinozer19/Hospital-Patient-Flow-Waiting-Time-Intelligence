
from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import precision_recall_fscore_support, confusion_matrix, classification_report
df=pd.read_csv("data/hospital_visits.csv",parse_dates=["Visit_Date"])
df["Arrival_DT"]=pd.to_datetime(df.Visit_Date.astype(str)+" "+df.Arrival_Time)
df["Appointment_DT"]=pd.to_datetime(df.Visit_Date.astype(str)+" "+df.Appointment_Time)
df["Arrival_Hour"]=df.Arrival_DT.dt.hour
df["Day_of_Week"]=df.Arrival_DT.dt.dayofweek
df["Arrival_vs_Appointment_Min"]=(df.Arrival_DT-df.Appointment_DT).dt.total_seconds()/60
df["Appointment_Lead_Min"]=0
df["Wait_Band"]=pd.cut(df.Waiting_Time,[-1,20,45,float("inf")],labels=["Low","Medium","High"])
m=df[df.Cancellation_Flag==0]
features=["Department","Visit_Type","Triage_Level","Arrival_Hour","Day_of_Week","Arrival_vs_Appointment_Min","Appointment_Lead_Min"]
X=m[features]; y=m.Wait_Band.astype(str)
cat=["Department","Visit_Type"]; num=[x for x in features if x not in cat]
prep=ColumnTransformer([("cat",Pipeline([("imp",SimpleImputer(strategy="most_frequent")),("oh",OneHotEncoder(handle_unknown="ignore"))]),cat),("num",Pipeline([("imp",SimpleImputer(strategy="median")),("sc",StandardScaler())]),num)])
models={"Logistic Regression":LogisticRegression(max_iter=1000,class_weight="balanced"),"Random Forest":RandomForestClassifier(n_estimators=300,random_state=42,class_weight="balanced",n_jobs=-1,min_samples_leaf=3)}
Xtr,Xte,ytr,yte=train_test_split(X,y,test_size=.2,random_state=42,stratify=y)
rows=[]
Path("outputs").mkdir(exist_ok=True)
for name,model in models.items():
    pipe=Pipeline([("prep",prep),("model",model)]); pipe.fit(Xtr,ytr); pred=pipe.predict(Xte)
    p,r,f,_=precision_recall_fscore_support(yte,pred,average="weighted",zero_division=0)
    rows.append([name,p,r,f])
    cm=confusion_matrix(yte,pred,labels=["Low","Medium","High"])
    pd.DataFrame(cm,index=["Actual Low","Actual Medium","Actual High"],columns=["Pred Low","Pred Medium","Pred High"]).to_csv("outputs/confusion_matrix_"+name.lower().replace(" ","_")+".csv")
    print("\n"+name); print(classification_report(yte,pred,zero_division=0))
pd.DataFrame(rows,columns=["Model","Precision","Recall","F1"]).round(4).to_csv("outputs/model_comparison.csv",index=False)
