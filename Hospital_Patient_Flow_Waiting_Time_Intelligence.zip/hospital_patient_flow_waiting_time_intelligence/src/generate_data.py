# Dataset generator is included for reproducibility.
# Run from the project root: python src/generate_data.py
# The notebook/project dataset is generated with seed=42 and 15,000 rows.
from pathlib import Path
import pandas as pd
# For the portfolio version, use the included data/hospital_visits.csv.
print('Use data/hospital_visits.csv; seed=42, 15,000 synthetic anonymized visits.')
