
from pathlib import Path
import pandas as pd, numpy as np
DATA=Path("data/hospital_visits.csv"); OUT=Path("outputs"); OUT.mkdir(exist_ok=True)
df=pd.read_csv(DATA,parse_dates=["Visit_Date"])
df["Arrival_DT"]=pd.to_datetime(df["Visit_Date"].astype(str)+" "+df["Arrival_Time"])
df["Appointment_DT"]=pd.to_datetime(df["Visit_Date"].astype(str)+" "+df["Appointment_Time"])
df["Arrival_Hour"]=df.Arrival_DT.dt.hour
df["Day_Name"]=df.Arrival_DT.dt.day_name()
df["Month"]=df.Visit_Date.dt.to_period("M").astype(str)
df["Appointment_Delay"]= (df.Arrival_DT-df.Appointment_DT).dt.total_seconds()/60
completed=df[df.Cancellation_Flag==0].copy()
summary=pd.DataFrame({
"Metric":["Total visits","Completed visits","Average waiting time (min)","Median waiting time (min)","90th percentile waiting time (min)","Average consultation time (min)","Cancellation rate (%)","Patient throughput (completed/day)"],
"Value":[len(df),len(completed),completed.Waiting_Time.mean(),completed.Waiting_Time.median(),completed.Waiting_Time.quantile(.90),completed.Consultation_Time.mean(),df.Cancellation_Flag.mean()*100,completed.groupby("Visit_Date").size().mean()]
})
summary.Value=summary.Value.round(2); summary.to_csv(OUT/"executive_kpis.csv",index=False)
dept=completed.groupby("Department").agg(Visits=("Visit_ID","count"),Avg_Wait=("Waiting_Time","mean"),Median_Wait=("Waiting_Time","median"),P90_Wait=("Waiting_Time",lambda x:x.quantile(.9)),Avg_Consult=("Consultation_Time","mean"),Avg_Total_Time=("Total_Time","mean")).sort_values("Avg_Wait",ascending=False)
dept.round(2).to_csv(OUT/"department_performance.csv")
doctor=completed.groupby(["Department","Doctor_ID"]).agg(Visits=("Visit_ID","count"),Avg_Wait=("Waiting_Time","mean"),Avg_Consult=("Consultation_Time","mean"),High_Wait_Rate=("Waiting_Time",lambda x:(x>45).mean()*100)).sort_values("Visits",ascending=False)
doctor.round(2).to_csv(OUT/"doctor_workload.csv")
hourly=completed.groupby("Arrival_Hour").agg(Visits=("Visit_ID","count"),Avg_Wait=("Waiting_Time","mean"),P90_Wait=("Waiting_Time",lambda x:x.quantile(.9))).sort_values("Visits",ascending=False)
hourly.round(2).to_csv(OUT/"hourly_flow.csv")
monthly=df.assign(Month=df.Visit_Date.dt.to_period("M").astype(str)).groupby("Month").agg(Total_Visits=("Visit_ID","count"),Completed_Visits=("Cancellation_Flag",lambda x:(x==0).sum()),Cancellations=("Cancellation_Flag","sum"))
monthly["Cancellation_Rate_%"]=monthly.Cancellations/monthly.Total_Visits*100; monthly.round(2).to_csv(OUT/"monthly_volume.csv")
bottlenecks=dept[(dept.Avg_Wait>dept.Avg_Wait.mean()+dept.Avg_Wait.std())|(dept.P90_Wait>60)]
bottlenecks.round(2).to_csv(OUT/"bottleneck_departments.csv")
print(summary.to_string(index=False))
