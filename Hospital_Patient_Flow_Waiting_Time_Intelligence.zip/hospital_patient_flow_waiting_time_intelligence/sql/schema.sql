
CREATE TABLE Departments (
 Department_ID INT PRIMARY KEY,
 Department_Name VARCHAR(100) NOT NULL,
 Capacity_Per_Hour INT NOT NULL
);
CREATE TABLE Doctors (
 Doctor_ID VARCHAR(20) PRIMARY KEY,
 Department_ID INT NOT NULL REFERENCES Departments(Department_ID),
 Available_Hours_Per_Day DECIMAL(5,2) NOT NULL
);
CREATE TABLE Patients (Patient_ID_Anonymized VARCHAR(20) PRIMARY KEY);
CREATE TABLE Calendar (
 Calendar_Date DATE PRIMARY KEY, Year INT, Month INT, Month_Name VARCHAR(20),
 Quarter INT, Day_Name VARCHAR(20), Day_Of_Week INT, Is_Weekend BOOLEAN
);
CREATE TABLE Appointments (
 Appointment_ID VARCHAR(20) PRIMARY KEY, Visit_ID VARCHAR(20) UNIQUE,
 Patient_ID_Anonymized VARCHAR(20), Department_ID INT, Doctor_ID VARCHAR(20),
 Appointment_Date DATE, Appointment_Time TIME, Visit_Type VARCHAR(30),
 Cancellation_Flag INT
);
CREATE TABLE Visits (
 Visit_ID VARCHAR(20) PRIMARY KEY, Patient_ID_Anonymized VARCHAR(20),
 Department_ID INT, Visit_Date DATE, Arrival_Time TIME, Appointment_Time TIME,
 Doctor_ID VARCHAR(20), Triage_Level INT, Waiting_Time DECIMAL(8,2),
 Consultation_Time DECIMAL(8,2), Total_Time DECIMAL(8,2), Visit_Type VARCHAR(30),
 Admission_Flag INT, Discharge_Time TIME, Cancellation_Flag INT
);
