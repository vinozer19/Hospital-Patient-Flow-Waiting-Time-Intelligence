
-- PostgreSQL examples
-- 1 Department waiting time
SELECT d.Department_Name, COUNT(*) Visits, ROUND(AVG(v.Waiting_Time),2) Avg_Wait_Min,
 PERCENTILE_CONT(.50) WITHIN GROUP(ORDER BY v.Waiting_Time) Median_Wait_Min,
 PERCENTILE_CONT(.90) WITHIN GROUP(ORDER BY v.Waiting_Time) P90_Wait_Min
FROM Visits v JOIN Departments d ON d.Department_ID=v.Department_ID
WHERE v.Cancellation_Flag=0 GROUP BY d.Department_Name ORDER BY Avg_Wait_Min DESC;

-- 2 Doctor workload
SELECT v.Doctor_ID,d.Department_Name,COUNT(*) Completed_Visits,
 ROUND(AVG(v.Waiting_Time),2) Avg_Wait_Min,ROUND(AVG(v.Consultation_Time),2) Avg_Consult_Min
FROM Visits v JOIN Departments d ON d.Department_ID=v.Department_ID
WHERE v.Cancellation_Flag=0 GROUP BY v.Doctor_ID,d.Department_Name ORDER BY Completed_Visits DESC;

-- 3 Peak hours
SELECT EXTRACT(HOUR FROM Arrival_Time) Arrival_Hour,COUNT(*) Visits,ROUND(AVG(Waiting_Time),2) Avg_Wait_Min
FROM Visits WHERE Cancellation_Flag=0
GROUP BY EXTRACT(HOUR FROM Arrival_Time) ORDER BY Visits DESC;

-- 4 Monthly patient volume
SELECT DATE_TRUNC('month',Visit_Date) Month,COUNT(*) Total_Visits,
 SUM(CASE WHEN Cancellation_Flag=0 THEN 1 ELSE 0 END) Completed_Visits
FROM Visits GROUP BY DATE_TRUNC('month',Visit_Date) ORDER BY Month;

-- 5 High-wait visits
SELECT Visit_ID,Department_ID,Doctor_ID,Visit_Date,Arrival_Time,Waiting_Time,Triage_Level
FROM Visits WHERE Cancellation_Flag=0 AND Waiting_Time>45 ORDER BY Waiting_Time DESC;

-- 6 Cancellation rate
SELECT Department_ID,COUNT(*) Scheduled_Visits,SUM(Cancellation_Flag) Cancellations,
 ROUND(100.0*SUM(Cancellation_Flag)/COUNT(*),2) Cancellation_Rate_Pct
FROM Visits GROUP BY Department_ID ORDER BY Cancellation_Rate_Pct DESC;

-- 7 Department comparison
SELECT d.Department_Name,COUNT(v.Visit_ID) Visits,ROUND(AVG(v.Waiting_Time),2) Avg_Wait,
 ROUND(AVG(v.Consultation_Time),2) Avg_Consult,ROUND(AVG(v.Total_Time),2) Avg_Total_Time,
 ROUND(100.0*AVG(v.Cancellation_Flag),2) Cancellation_Rate_Pct
FROM Visits v JOIN Departments d ON d.Department_ID=v.Department_ID
GROUP BY d.Department_Name ORDER BY Avg_Wait DESC;

-- 8 Capacity-gap signal
WITH hourly AS (
 SELECT Department_ID,EXTRACT(HOUR FROM Arrival_Time) Arrival_Hour,COUNT(*) Visits
 FROM Visits WHERE Cancellation_Flag=0
 GROUP BY Department_ID,EXTRACT(HOUR FROM Arrival_Time)
)
SELECT h.Department_ID,h.Arrival_Hour,h.Visits,d.Capacity_Per_Hour,
 h.Visits-d.Capacity_Per_Hour Capacity_Gap
FROM hourly h JOIN Departments d ON d.Department_ID=h.Department_ID
ORDER BY Capacity_Gap DESC;
