
# Hospital Patient Flow & Waiting-Time Intelligence

End-to-end healthcare **operational analytics and decision-support** project using Python, SQL, Machine Learning and Power BI.

> **Important:** This is not a clinical diagnosis or treatment system. The dataset is synthetic and anonymized for portfolio/demo use.

## Dataset
15,000 synthetic patient visits with:
Visit_ID, Patient_ID_Anonymized, Department, Visit_Date, Arrival_Time, Appointment_Time, Doctor_ID, Triage_Level, Waiting_Time, Consultation_Time, Total_Time, Visit_Type, Admission_Flag, Discharge_Time, Cancellation_Flag.

No names, addresses, phone numbers or other direct PII are included.

## Run
```bash
pip install -r requirements.txt
python src/analyze.py
python src/predict_wait.py
```

## Predictive analytics
Predicts:
- Low wait: <=20 min
- Medium wait: 21-45 min
- High wait: >45 min

Compared models:
- Logistic Regression
- Random Forest

Metrics:
Precision, Recall, F1 and confusion matrix.

Outcome leakage is avoided: Waiting_Time, Total_Time, Consultation_Time and Discharge_Time are not used as prediction features.

## Analytics
The project covers:
- patient volume
- waiting times
- department workload
- doctor workload
- peak hours
- appointment delays
- cancellation/no-show patterns
- consultation duration
- patient flow
- bottleneck and capacity-gap detection

## Power BI
Six pages:
1. Hospital Operations Overview
2. Patient Flow
3. Waiting-Time Analysis
4. Department Performance
5. Doctor Workload
6. Bottleneck Analysis

See `powerbi/README.md` and `powerbi/DAX_measures.txt`.

## SQL
`sql/schema.sql` contains normalized tables:
Patients, Visits, Departments, Doctors, Appointments, Calendar.

`sql/analytics_queries.sql` contains department, doctor, peak-hour, monthly-volume, high-wait, cancellation, comparison and capacity-gap queries.

## Operational recommendations
Use findings to support:
1. Staffing adjustments toward sustained high-wait/high-volume periods.
2. Appointment-slot redistribution around demand peaks.
3. Department capacity changes where capacity gaps persist.
4. Flexible peak-hour resource allocation.

## Portfolio positioning
This complements a Hospital Queue Management application: the queue app manages operational transactions, while this project analyzes historical flow, identifies bottlenecks, compares capacity and supports management decisions.
