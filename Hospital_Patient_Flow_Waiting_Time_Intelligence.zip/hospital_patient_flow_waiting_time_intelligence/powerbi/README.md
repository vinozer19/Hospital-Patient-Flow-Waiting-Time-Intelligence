
# Power BI pages

## 1. Hospital Operations Overview
KPI cards: Total Visits, Average Wait, Median Wait, P90 Wait, Average Consultation, Cancellation Rate, Peak Hour.
Charts: monthly volume, department volume, wait-band mix, daily throughput.

## 2. Patient Flow
Hourly volume, day/hour heatmap, completed vs cancelled, visit-type mix, throughput trend.

## 3. Waiting-Time Analysis
Average/median/P90 wait by department, wait-band distribution, appointment delay by hour, high-wait trend.

## 4. Department Performance
Department scorecard, volume-vs-wait scatter, consultation duration, cancellation rate, capacity-gap matrix.

## 5. Doctor Workload
Visits per doctor, average wait, average consultation, high-wait rate, department slicer.

## 6. Bottleneck Analysis
Top bottleneck departments, peak-hour capacity gap, high-wait visits, appointment-delay trend, Department x Hour bottleneck matrix.

Recommended thresholds:
- High wait: >45 min
- Critical P90: >60 min
- High cancellation: >8%

Model relationships:
Calendar -> Visits; Departments -> Visits; Doctors -> Visits; Patients -> Visits; Appointments -> Visits.
